declare module "remark-collapse";
